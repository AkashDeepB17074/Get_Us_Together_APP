
#include <bits/stdc++.h>
using namespace std;


int minLength(string S, string P){
    int sizeS = S.length();
    int sizeT = P.length();


    vector<int> needToFind(256,0);
    vector<int> hasFound(256,0);
    

    int count = 0;
    int minLen = INT_MAX;
    string res = "";
    
    // store the frequency of charachters in string P
    for(int i = 0;i<sizeT;i++) {
        needToFind[P[i]]++;
    }


    for(int p = 0,q = 0;q<sizeS;q++) {
        
        // if char is not present in string S then do nothing just increase the size of window
        if(needToFind[S[q]] == 0) continue;
        
        // if we found the char in string S then increament the count in hasfound map
        hasFound[S[q]]++;

        // if freq of char which are found is less then char have to find then increament the size of window       
        if(hasFound[S[q]] <= needToFind[S[q]] ) count++;
        
        // if window size becomes equal to size of string P
        // then check found char freq is greater then the char needed to find then decrease the size of window
        if(count == sizeT) {
            while(hasFound[S[p]] == 0 || hasFound[S[p]] > needToFind[S[p]] ) {
                if(hasFound[S[p]] > needToFind[S[p]]) hasFound[S[p]]--;
                p++;
            }
            minLen = min(minLen,q - p + 1);
        }
    }
    return minLen;
}


int main(){

    // string S = "timetopractice";
    // string P = "toc";

    string S = "zoomlazapzo";
    string P = "oza";

    cout<<minLength(S, P);
}








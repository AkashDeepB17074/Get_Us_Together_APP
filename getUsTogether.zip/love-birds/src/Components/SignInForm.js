import React from 'react'

var SignInForm = function(props){

    // const submitLoginDetails = (event) => {
    //     this.props.getLoginCredentials("there is data which will be passed ");
    //     event.preventDefault();
    // } 

    return (
        <form action="POST" onSubmit={console.log("hey")}>
            <div class="input">
                <h1>Sign In</h1>
            </div>
            <div class="input inputField">
                <label for="email">Email</label>
                <input type="text" placeholder="email" name="email"/>
            </div>
            <div class="input inputField">
                <label for="password">Password</label>
                <input type="password" placeholder="password" name="password"/>
            </div>
            <div class="input  button">
                <button type="submit">Sign In</button>
                <button type="submit">Sign Up</button>
            </div>
            
        </form>
    )    

}

export default SignInForm;
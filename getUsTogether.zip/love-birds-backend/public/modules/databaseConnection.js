var express = require('express');
const mongoose = require('mongoose')

// const CONNECTION_URL = 'mongodb+srv://LoveBirdsUser:<password>@kingdeepcluster.7sjxx.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'
const CONNECTION_URL = 'mongodb://localhost:27017/?readPreference=primary&appname=MongoDB%20Compass&ssl=false'

mongoose.connect(CONNECTION_URL, {useNewUrlParser: true, useCreateIndex: true, useUnifiedTopology: true});

const db = mongoose.connection;

db.on('error', console.error.bind(console, "\x1b[31m" , "[ ####### ERR1! CONNECTING DATABASE ####### ]"))
db.on('connected', () => console.log("\x1b[32m\x1b[2m", "[ ####### CONNECTED TO DATABASE ####### ]"))
db.on('dissconected', ()=> console.log("\x1b[34m" , "[ ####### ERR! CONNECTING DATABASE ####### ]"))

module.exports = db;
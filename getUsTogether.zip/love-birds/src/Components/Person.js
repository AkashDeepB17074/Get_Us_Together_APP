import React, { Component } from 'react'
import '../Stylesheets/personStyle.css'
import Img from './Img'

// object-fit : contain;

function Person(props){
    
    //variales
    var isDown =  false
    var isTranslated =  false
    var startX = 0
    var startY = 0
    var currentImageInfo = {pervImage: 0, size: 0}
    var swipeLimit =  200
    var swipeRotation =  ""
    var changePic =  ""
    var maxTransX = 1
    var maxTransY = 1
    var minTransX =-1
    var minTransY =-1
    var maxTransLimit =  3
    var person = ""

    React.useEffect(() => {
        function changeImage(e){
            if(currentImageInfo.size == 0) return;
            var person = document.getElementsByClassName('person')
            var person = person[person.length-1]
            var images = person.childNodes[1]
            var pervImage = images.children[currentImageInfo.pervImage] 
            pervImage.style.zIndex = -1;
            var inc = 0;
            if(changePic == "next") inc = 1
            else if(changePic == "prev") inc = -1;
            var index = (currentImageInfo.pervImage + currentImageInfo.size + inc)%currentImageInfo.size
           
            currentImageInfo.pervImage = index
            images.children[index].style.zIndex = 5;
        }


        window.addEventListener('mousemove', (e)=>{

            // console.log("mouseMoveEvent")
            //mouseMoveEvent(e)
            if(!isDown) return
            e.preventDefault()
            /// Move operation
    
            const x = e.pageX - person.offsetLeft;
            const y = e.pageY - person.offsetTop;
            const walkX = x-startX;
            const walkY = y-startY;
            const velo = 17;
            const limit = 30;
            let rotation = (walkX>=0) ? ((walkX/velo >= limit)?limit:walkX/velo) 
                                        : ((walkX/velo <=-limit)?-limit:walkX/velo);
                                        
            
            //
            maxTransX = Math.max(maxTransX, x - startX);
            maxTransY = Math.max(maxTransY, y - startY);
            minTransX = Math.min(minTransX, x - startX);
            minTransY = Math.min(minTransY, y - startY);
    
            if(swipeRotation == "up"){
                person.style.transformOrigin = "50% 100%";
            }else if(swipeRotation == "down"){
                person.style.transformOrigin = "50% 0";
                rotation = -rotation;
            }
            
            if((maxTransX > maxTransLimit || minTransX < -maxTransLimit) || 
                (maxTransY > maxTransLimit || minTransY < -maxTransLimit)){
                
                    person.style.transform = `translate(${walkX/2}px, ${walkY/2}px) rotate(${rotation}deg)`;
                    isTranslated = true;
            }
    
        })

        window.addEventListener('mouseup', (e)=>{
            if(e.button != 0) return

            console.log("mouseUpEvent")
            // console.log("mouse up window");
            if(isDown && !isTranslated){
                changeImage(e);
                console.log("changePic")
            }
            isDown = false;
            if(isTranslated){
                console.log('\n--isTranslated\n');
                person.classList.add('transition');
                let diffX = e.clientX - startX;
                if(diffX > swipeLimit || diffX < -swipeLimit){
                    // performOperation(diffX);
                    console.log("perform Operation ")
                    person.remove()
                    console.log(e)
                }
                person.style.transform = `translate(${0}px, ${0}px)`;
                isTranslated = false;
            }
        })
    })

    function mouseDownEvent(e){
        if(e.button != 0) return

        console.log("mouseDownEvent")
        person = document.getElementsByClassName('person')
        person = person[person.length-1]
        
        isDown = true;
        
        person.classList.remove('transition');
        
        startX = e.clientX - person.offsetLeft;
        startY = e.clientY - person.offsetTop;
        
        // console.log(e)
        // console.log(person, person.getBoundingClientRect())
        // console.log('start', startX, startY)

        maxTransX=1
        maxTransY = 1;
        minTransX=-1
        minTransY = -1;
        
        var rect = person.getBoundingClientRect();
        swipeRotation=(rect.height/2 > e.clientY - rect.y)?"up":"down";
        changePic = (rect.width/2 < e.clientX - rect.x)?"next":"prev";
        // swipeRotation=(person.offsetHeight/2 > e.offsetY)?"up":"down";
        // changePic = (person.offsetWidth/2 < e.offsetX)?"next":"prev";
    }


    const personData = props.personData
    // console.log(person);
    
    const base_dir = "../Data/photos/"
    
    // person images array
    let count = 0;
    const personImages = personData.images.map((x, index)=>{
        // console.log(x)
        const imgAdd = x.split('.')[0];
        return(
            <div key={index} className="person_image" >
                <img key={index} className="real_person_images" src={require(`../Data/newPhotos/${imgAdd}.jpg`).default}/>
                {/* <img key={index} alt="person image" className="real_person_images" src={`../Data/newPhotos/${imgAdd}.jpg`}/> */}
            </div>
        )
    })
     
    //scroll buttons array
    const scrollButtons = []
    currentImageInfo.size = personImages.length
    for(let i=0; i<personImages.length; i++){
        scrollButtons.push( <button key={i} className="changeButton"> </button> )
    }
     
      
       
    return(
        <div className="person" onMouseDown={mouseDownEvent}>
            <div className="scroll">
                {scrollButtons}
            </div>
            <div className="image_box">
        
                {personImages}
                {/* <Img/> */}
                <div style={{position:'absolute', bottom:'0', left: '0', transform:'translate(30px, -30px)', fontSize:"15pt"}}>
                    User 13
                    <em style={{display:'block'}}> Blah Blah </em> 
                </div>
            </div>
              
        </div>
    )
           
}
              
export default Person



// state={
//     isDown: false,
//     isTranslated: false,
//     start: {x:0, y:0},
//     swipeLimit: 200,
//     swipeRotation: "",
//     changePic: "",
//     maxTrans:{x:1,y:1},
//     minTrans:{x:-1, y:-1},
//     maxTransLimit: 3
// }
import React, { Component } from 'react'
import '../Stylesheets/personStyle.css'
import Img from './Img'

class Person extends Component{
    
    constructor(){
        super()
        
        this.state={
            isDown: false
        }

        //variales
        this.isDown =  false
        this.isTranslated =  false
        this.startX = 0
        this.startY = 0
        this.swipeLimit =  200
        this.swipeRotation =  ""
        this.changePic =  ""
        this.maxTransX = 1
        this.maxTransY = 1
        this.minTransX =-1
        this.minTransY =-1
        this.maxTransLimit =  3
        this.person = ""
        this.mouseDownEvent = this.mouseDownEvent.bind(this)
        this.mouseUpEvent = this.mouseUpEvent.bind(this)
        this.mouseMoveEvent = this.mouseMoveEvent.bind(this)
    }
    mouseDownEvent(e){
        console.log("mouseDownEvent")
        this.person = document.getElementsByClassName('person')
        this.person = this.person[this.person.length-1]
        this.person.style.transform = "translate(-50px)"

        this.isDown = true;
            
        this.person.classList.remove('transition');
        
        this.startX = e.clientX - this.person.offsetLeft;
        this.startY = e.clientY - this.person.offsetTop;
        
        
        this.maxTransX=1
        this.maxTransY = 1;
        this.minTransX=-1
        this.minTransY = -1;


        this.swipeRotation=(this.person.offsetHeight/2 > e.offsetY)?"up":"down";
        this.changePic = (this.person.offsetWidth/2 < e.offsetX)?"next":"prev";

    }
    mouseUpEvent(e){
        console.log("mouseUpEvent")
        // console.log("mouse up window");
        if(this.isDown && !this.isTranslated){
            // this.changeImage(changePic);
            console.log("changePic")
        }
        this.isDown = false;
        if(this.isTranslated){
            console.log('\n--isTranslated\n');
            this.person.classList.add('transition');
            let diffX = e.clientX - this.startX;
            if(diffX > this.swipeLimit || diffX < -this.swipeLimit){
                // performOperation(diffX);
                console.log("perform Operation ")
            }
            this.person.style.transform = `translate(${0}px, ${0}px)`;
            this.isTranslated = false;
        }

    }
    mouseMoveEvent(e){
        console.log("mouseMoveEvent")
        //mouseMoveEvent(e)
        if(!this.isDown) return
        e.preventDefault()
        /// Move operation

        const x = e.pageX - this.person.offsetLeft;
        const y = e.pageY - this.person.offsetTop;
        const walkX = x-this.startX;
        const walkY = y-this.startY;
        const velo = 17;
        const limit = 30;
        let rotation = (walkX>=0) ? ((walkX/velo >= limit)?limit:walkX/velo) 
                                    : ((walkX/velo <=-limit)?-limit:walkX/velo);
                                    
        
        //
        this.maxTransX = Math.max(this.maxTransX, x - this.startX);
        this.maxTransY = Math.max(this.maxTransY, y - this.startY);
        this.minTransX = Math.min(this.minTransX, x - this.startX);
        this.minTransY = Math.min(this.minTransY, y - this.startY);

        if(this.swipeRotation == "up"){
            this.person.style.transformOrigin = "50% 100%";
        }else if(this.swipeRotation == "down"){
            this.person.style.transformOrigin = "50% 0";
            rotation = -rotation;
        }
        
        if((this.maxTransX > this.maxTransLimit || this.minTransX < -this.maxTransLimit) || 
            (this.maxTransY > this.maxTransLimit || this.minTransY < -this.maxTransLimit)){
            
                this.person.style.transform = `translate(${walkX/2}px, ${walkY/2}px) rotate(${rotation}deg)`;
                this.isTranslated = true;
        }


    }





    render(){

        const person = this.props.personData
        // console.log(person);

        const base_dir = "../Data/photos/"

        // person images array
        let count = 0;
        const personImages = person.images.map((x, index)=>{
            // console.log(x)
            const imgAdd = x.split('.')[0];
            return(
                <div key={index} className="person_image">
                    <img key={index} className="real_person_images" src={require(`../Data/photos/${imgAdd}.jpg`).default}/>
                </div>
            )
        })

        //scroll buttons array
        const scrollButtons = []
        for(let i=0; i<personImages.length; i++){
            scrollButtons.push( <button key={i} className="changeButton"> </button> )
        }



        return(
            <div className="person" onMouseDown={this.mouseDownEvent} onMouseUp={this.mouseUpEvent} onMouseMove={this.mouseMoveEvent}>
                <div className="scroll">
                    {scrollButtons}
                </div>
                <div className="image_box">
                    {personImages}
                    {/* <Img/> */}
                </div>
                

            </div>
        )
    }
}

export default Person



// this.state={
//     isDown: false,
//     isTranslated: false,
//     start: {x:0, y:0},
//     swipeLimit: 200,
//     swipeRotation: "",
//     changePic: "",
//     maxTrans:{x:1,y:1},
//     minTrans:{x:-1, y:-1},
//     maxTransLimit: 3
// }
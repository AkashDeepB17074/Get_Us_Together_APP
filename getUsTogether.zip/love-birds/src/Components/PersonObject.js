import React, { Component } from 'react'

function PersonObject(props){
    return (
        <div className="person">
            msg = {props.msg}
            <div className="scroll">
                {props.scrollButtons}
            </div>
            <div className="image_box">
        
                {props.personImages}
                {/* <Img/> */}
            </div>
              
        </div>
    )
}

export default PersonObject

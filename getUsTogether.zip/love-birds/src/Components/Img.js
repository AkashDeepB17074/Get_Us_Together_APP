import React from 'react'

const Img = () => {
    return (
        <div>
            
        </div>
    )
}

export default Img

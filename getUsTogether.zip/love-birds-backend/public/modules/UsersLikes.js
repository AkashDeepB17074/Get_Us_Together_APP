var db = require('./databaseConnection')
const mongoose = require('mongoose')

var userLikesSchema = new mongoose.Schema({
    user1:{
        type: String,
        required: true
    },
    user2:{
        type: String,
        required: true
    },
    option:{
        like : Buffer,
        required: true,
        default: false
    }
})

userLikesSchema.methods.doSomething = function(){
    console.log('hey user')
}

var likesModel = mongoose.model('UserLikes', userLikesSchema)
module.export = likesModel

import React, { Component } from 'react'

class MessageBox extends Component {
    constructor(){
        super()
        this.state = {
            cordinates: "x,y"
        }
    }

    render(props) {
        return (
            <div className="message-box">
                <h3>Page X : <p> 0 </p></h3>
                <h3>Page Y : <p> 0 </p></h3><br />

                <h3>Client X : <p> 0 </p></h3>
                <h3>Client Y : <p> 0 </p></h3><br />
                
                <h3>Offset X : <p> 0 </p></h3>
                <h3>Offset Y : <p> 0 </p></h3><br />
                
                <h3>Screen X : <p> 0 </p></h3>
                <h3>Screen Y : <p> 0 </p></h3><br />

                <h3>start X : <p> 0 </p></h3>
                <h3>Start Y : <p> 0 </p></h3><br />

                <h3>diff X : <p> 0 </p></h3>
                <h3>diff Y : <p> 0 </p></h3><br/ >

                <h3>person Height : <p> 0 </p></h3>
                <h3>person Width : <p> 0 </p></h3><br/>

                <h3>window mouse X : <p> 0 </p></h3>
                <h3>window mouse Y : <p> 0 </p></h3><br /><br/>
            </div>
        )
    }
}

export default MessageBox

const mongoose = require('mongoose')
const db = require('./databaseConnection')

var matchedUserSchema = new mongoose.Schema({
    users:{
        type: String,
        required: true,

    },
    // matches:{
    //     type: [{
    //         user: String,
    //         time: {type: Date, default: Date.now}
    //     }]
    // }
    matches:{
        type: Map,
        of: String
    }
})

matchedUserSchema.methods.doSomething = function(){
    console.log('its A match')
}

var matchesModel = mongoose.model('MatchedUsers', matchedUserSchema)
module.exports = matches
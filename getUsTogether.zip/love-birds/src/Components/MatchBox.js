import React, { Component } from 'react'

function MatchBox(){
    return (
        <div className="match_box">
            Matchbox
        </div>
    )

}

export default MatchBox

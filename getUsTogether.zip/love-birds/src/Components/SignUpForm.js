import React, { Component } from 'react'

class SignUpForm extends Component {
    constructor(){
        super()
    }
    

    render() {
        return (
            <form action="POST">
                <div class="input">
                    <h1>Sign In</h1>
                </div>
                <div class="input inputField">
                    <label for="email">Email</label>
                    <input type="text" placeholder="email" name="email"/>
                </div>
                <div class="input inputField">
                    <label for="password">Password</label>
                    <input type="password" placeholder="password" name="password"/>
                </div>
                <div class="input inputField">
                    <label for="password">Confirm Password</label>
                    <input type="password" placeholder="password" name="password"/>
                </div>
                <div class="input">
                    <label for="gender">Gender</label>
                    <select name="gender" >
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                    </select>
                </div>
                <div class="input  button">
                    <button type="submit">Sign In</button>
                    <button type="submit">Sign Up</button>
                </div>
                    
            </form>
        )
    }
}

export default SignUpForm

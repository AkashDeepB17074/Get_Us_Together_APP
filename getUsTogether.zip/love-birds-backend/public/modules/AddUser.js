const db = require('./databaseConnection')
const mongoose = require('mongoose')
const bcrypt = require('bcryptjs')

var AddUserSchema = new mongoose.Schema({
    id: _id,
    name: String,
    email:{
        type:email,
        required:true,
        index:{
            unique:true
        }
    },
    password:{
        type:String,
        required: true
    },
    age: {
        type:Number,
        min: 18, 
        max: 65
    }, 
    gender: {
        type: Boolean,
        required: true
    },
    distance: Number,
    discription: String,
    images: [String],
    hobbies: [String]
    // isSuperLike: Boolean,
    // available: Boolean
})

AddUserSchema.methods.accountVerification = function(pass){
    console.log("AddUserSchema", this.password, pass)
}

AddUserSchema.methods.addProfile

var userModel = mongoose.model('usermanager', AddUserSchema)
module.exports = userModel
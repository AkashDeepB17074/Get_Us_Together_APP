import React, {Component} from 'react'
import SwipeBox from './SwipeBox'

// Main container contains Conditional Rendering Between:: 
//          SwipeBox 
//          profileBox
//          LodingBox

class MainContainer extends Component{
    constructor(){
        super()
        this.state = {
            message: "MainContainer"
        }
    }
    render(){
        return(
            <div className="main_container">
                
                <SwipeBox />
                {/* <LoadingBox/>
                <Profile /> */}


            </div>
        )
    }
}
export default MainContainer
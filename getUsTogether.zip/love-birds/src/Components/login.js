import React, { Component } from 'react'
import axios from 'axios';
import '../Stylesheets/loginForm.css'
import SignUpForm from "./SignUpForm"
import SignInForm from "./SignInForm"

// import {extendedObservalble} from 'mobx'



 

class login extends Component {
    constructor(){
        super()
        this.state = {
            signInCred : {
                email: "",
                password: ""
            },
            signUpCred : {
                email: "",
                password: "",
                Confpassword: "",
                name: "",
                gender: "",
                dob: "",
            }
        }

        // extendedObservalble(this, {
        //     loading: true,
        //     isLoggedIn: false,
        //     email: ''
        // })

    }

    // create call back function for getting data for child 
    getLoginCredentials = function(event){
        console.log(event)
    }


    render() {
        var Form;
        if(this.state.doSignUp){
            Form = <SignUpForm loginDetails = {this.getLoginCredentials}/>;
        }else {
            Form = <SignInForm loginDetails = {this.getLoginCredentials}/>
        }
        return (
            <div class="loginContainer">
                <div class="sideImage"></div>
                <div class="loginPage">
                    <div class="loginFormDiv">
                        {Form}
                    </div>
                </div>
            </div>
        )
    }
}

export default login

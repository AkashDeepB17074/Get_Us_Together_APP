import logo from './logo.svg';
import './App.css';
import './Stylesheets/style.css'
import React from 'react'
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from 'react-router-dom'

// import DataSet from "./data/data.json"

// Components 
import MainContainer from './Components/MainContainer'
import SideMenu from './Components/SideMenu'
import Footer from './Components/Footer'
import Login from './Components/login'

function App() {
  return (
    <Router>
      <switch>
        {/* route home */}
        <Route path='/home'>
          <div className="RootElement">
            <div className="container">  
              <SideMenu />
              <MainContainer />
              <Footer />
            </div>
          </div>
        </Route>

        {/* route login */}
        <Route path='/login'>
          <Login/>
        </Route>

      </switch>
    </Router>
  );
}

export default App;

import React, { Component } from 'react'
import usrImage from './user.png'


import im1 from '../Data/newPhotos/michael-dam-mEZ3PoFGs_k-unsplash.jpg'
import im2 from '../Data/newPhotos/natasha-kasim-KsmXcL_dnzM-unsplash.jpg'
import im3 from '../Data/newPhotos/sean-kong-_l9LXmpgzRY-unsplash.jpg'


import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
} from "react-router-dom"

import '../Stylesheets/sideMenu.css'

// Components
import MessageBox from "./MessageBox"
import MatchBox from "./MatchBox"

class SideMenu extends Component {
    constructor(){
        super()
        this.state = {
            renderWhat: true,
            userImagePath:usrImage,
            routeMessage:""
        }
    }
    style = {
        height:"50px",
    }

    

    callApi(){
        fetch("http://localhost:4000/")
        .then(res => res.text())
        .then(res => {this.setState({routeMessage: res})});
    }

    componentDidMount(){
        this.callApi()
    }

    
    render() {
        let ursimgcss = {
            "height": "45px", 
            "width": "45px",
            "borderRadius": "25px"
        }
        let inputStyle = {color:"blue", width:"10px",
        height:'40px'
    };
        return (
            <div  className="side_menu">
                {/* Header */}
                <div className="header">
                    <div className="user_image"><button className="image"><img style={ursimgcss} src={this.state.userImagePath}/></button><span>User Image</span></div>
                    <div className="store_button"><button className="store"><i className="fas fa-store"></i></button></div>
                </div>
                
                
                <div className="menu">
                    {/* <h1>message :: {this.state.routeMessage}</h1> */}
                    <div className="nav_button_box" style={this.style}>
                        <input type="button" style={inputStyle} className="nav_button message_button" value="Message"></input>
                        <input type="button" style={inputStyle} className="nav_button match_button" value="Match"></input>
                    </div>
                    {/* {(this.state.renderWhat)?<MessageBox/>:<MatchBox/>} */}
                 <div >
                <div className="header">
                    <div className="user_image"><button className="image"><img style={ursimgcss} src={im1}/></button><span>User 1</span></div>
                    </div>
                <div className="header">
                    <div className="user_image"><button className="image"><img style={ursimgcss} src={im2}/></button><span>User 2</span></div>
                    </div>
                <div className="header">
                    <div className="user_image"><button className="image"><img style={ursimgcss} src={im3}/></button><span>User 3</span></div>
                    </div>

                </div>
                     </div>   
                

            </div>
        )
    }
}

export default SideMenu


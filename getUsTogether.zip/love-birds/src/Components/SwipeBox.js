import React, { Component } from 'react'
import DataSet from '../Data/data.json'
import Person from './Person'

class SwipeBox extends Component {
    constructor(){
        super()
        this.state ={
            person: DataSet 
        }
    }


    render() {
        const data = DataSet.map(x => <Person personData={x} key={x.id}/>)
        return (
            <div className="swipe_box">
                <div className="person_box">
                    {/* <Person personData={this.state.person[0]} /> */}

                    {/*
                        Conditional rendering 
                        either person information 
                        or person data should display 
                     */}

                    {data}
                </div>
                
                <div className="button_box">
                    <button className="ges-button" id="rewind">
                        <label><i className="fas fa-history"></i></label>
                    </button>
                    <button className="ges-button" id="dislike">
                        <label><i className="fas fa-times"></i></label>
                    </button>
                    <button className="ges-button" id="superLike">
                        <label><i className="fas fa-star"></i></label>
                    </button>
                    <button className="ges-button" id="like">
                        <label><i className="fas fa-heart"></i></label>
                    </button>
                    <button className="ges-button" id="profile">
                        <label><i className="fas fa-user-alt"></i></label>
                    </button>
                </div>
            </div>
        )
    }
}

export default SwipeBox

var express = require('express');
// var db = require('../public/modules/databaseConnection');

var route = express.Router()

console.log('########  SERVER STARTED ########');

route.get('/', (req, res)=>{
  res.send('server yo yo is running fuck absolutely fine');
});

module.exports = route 









